# Crazy Card Game

Assignment documentation is here: https://courses.grainger.illinois.edu/cs126/fa2019/assignments/crazy-cardgame/

Good luck!
